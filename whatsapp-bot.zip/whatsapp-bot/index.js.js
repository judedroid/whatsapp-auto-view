const {
    makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    delay,
    makeCacheableSignalKeyStore
} = require("@whiskeysockets/baileys");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const qrcode = require("qrcode-terminal");
const pino = require("pino");
const express = require("express"); // Required for Render

// --- CONFIGURATION ---
const GEMINI_API_KEY = "YOUR_GOOGLE_GEMINI_API_KEY_HERE";
const SYSTEM_INSTRUCTION = "You are a helpful AI assistant for my business. Be professional and concise.";
const PORT = process.env.PORT || 3000;

// --- RENDER KEEP-ALIVE SERVER ---
const app = express();
app.get("/", (req, res) => res.send("Bot is running logic..."));
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));

// --- AI SETUP ---
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ 
    model: "gemini-1.5-flash", 
    systemInstruction: SYSTEM_INSTRUCTION 
});

const lastManualReplyTime = {};

async function startBot() {
    // Auth info is stored in a local folder. 
    // NOTE: On Render Free, this folder is deleted on every restart.
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');

    const sock = makeWASocket({
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
        },
        printQRInTerminal: true,
        logger: pino({ level: "silent" }),
        browser: ["RenderBot", "Chrome", "1.0.0"],
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect, qr } = update;
        if (qr) {
            console.log("--- SCAN THE QR CODE BELOW ---");
            qrcode.generate(qr, { small: true });
        }
        if (connection === "close") {
            const shouldReconnect = lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) startBot();
        } else if (connection === "open") {
            console.log("✅ Bot connected to WhatsApp!");
        }
    });

    sock.ev.on("messages.upsert", async (m) => {
        const msg = m.messages[0];
        if (!msg.message) return;

        const remoteJid = msg.key.remoteJid;

        // 1. STATUS INTERACTION LOGIC
        if (remoteJid === 'status@broadcast') {
            try {
                const emojis = ["🔥", "👏", "🙌", "❤️"];
                const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
                
                await sock.readMessages([msg.key]); // "View" the status
                await delay(3000); // Wait 3 seconds to look natural
                
                await sock.sendMessage(remoteJid, {
                    react: { text: randomEmoji, key: msg.key }
                }, { statusForward: true });
                
                console.log(`Reacted ${randomEmoji} to status from: ${msg.pushName}`);
            } catch (e) { /* Ignore status errors */ }
            return;
        }

        // 2. AI AUTO-REPLY LOGIC
        const isMe = msg.key.fromMe;
        const messageText = msg.message.conversation || msg.message.extendedTextMessage?.text;

        if (isMe) {
            lastManualReplyTime[remoteJid] = Date.now();
            return;
        }

        if (messageText && !remoteJid.endsWith('@g.us')) {
            const lastManual = lastManualReplyTime[remoteJid] || 0;
            const fiveMinutes = 5 * 60 * 1000;

            if (Date.now() - lastManual > fiveMinutes) {
                try {
                    const result = await model.generateContent(messageText);
                    const aiText = result.response.text();
                    await sock.sendMessage(remoteJid, { text: aiText }, { quoted: msg });
                } catch (err) {
                    console.error("Gemini Error:", err);
                }
            }
        }
    });
}

startBot();